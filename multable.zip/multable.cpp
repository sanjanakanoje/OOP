Compiling single file...
--------
- Filename: D:\23UAM048\multable.cpp
- Compiler Name: TDM-GCC 4.9.2 64-bit Release

Processing C++ source file...
--------
- C++ Compiler: C:\Program Files (x86)\Dev-Cpp\MinGW64\bin\g++.exe
- Command: g++.exe "D:\23UAM048\multable.cpp" -o "D:\23UAM048\multable.exe"  -I"C:\Program Files (x86)\Dev-Cpp\MinGW64\include" -I"C:\Program Files (x86)\Dev-Cpp\MinGW64\x86_64-w64-mingw32\include" -I"C:\Program Files (x86)\Dev-Cpp\MinGW64\lib\gcc\x86_64-w64-mingw32\4.9.2\include" -I"C:\Program Files (x86)\Dev-Cpp\MinGW64\lib\gcc\x86_64-w64-mingw32\4.9.2\include\c++" -L"C:\Program Files (x86)\Dev-Cpp\MinGW64\lib" -L"C:\Program Files (x86)\Dev-Cpp\MinGW64\x86_64-w64-mingw32\lib" -static-libgcc

Compilation results...
--------
- Errors: 0
- Warnings: 0
- Output Filename: D:\23UAM048\multable.exe
- Output Size: 1.83260917663574 MiB
- Compilation Time: 0.30s
